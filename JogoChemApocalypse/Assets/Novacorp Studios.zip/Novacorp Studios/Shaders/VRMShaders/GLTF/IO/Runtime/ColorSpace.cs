﻿namespace VRMShaders
{
    public enum ColorSpace
    {
        sRGB,
        Linear,
    }
}
