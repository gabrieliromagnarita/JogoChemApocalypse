# MToon
Toon Shader with Unity Global Illumination

## Tutorial
https://www.slideshare.net/VirtualCast/vrm-mtoon

## Version
v3.8

## Release Note
https://github.com/Santarh/MToon/releases
