namespace MToon
{
    public static partial class Utils
    {
        public const string Implementation = "Santarh/MToon";
        public const int VersionNumber = 38;
    }
}
