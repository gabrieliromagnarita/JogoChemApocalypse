namespace MToon
{
    public enum EditorRotationUnit
    {
        Rounds = 0,
        Degrees = 1,
        Radians = 2,
    }
}