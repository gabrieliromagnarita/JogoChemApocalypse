﻿namespace VRMShaders.VRM10.MToon10.Runtime
{
    public static class MToon10Meta
    {
        public static readonly string UnityShaderName = "VRM10/MToon10";
    }
}