﻿namespace VRMShaders.VRM10.MToon10.Runtime
{
    public enum UnityAlphaToMaskMode
    {
        Off = 0,
        On = 1,
    }
}