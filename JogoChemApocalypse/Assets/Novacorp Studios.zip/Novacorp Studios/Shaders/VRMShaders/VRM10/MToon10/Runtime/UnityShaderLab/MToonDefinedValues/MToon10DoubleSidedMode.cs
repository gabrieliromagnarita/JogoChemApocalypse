﻿namespace VRMShaders.VRM10.MToon10.Runtime
{
    public enum MToon10DoubleSidedMode
    {
        Off = 0,
        On = 1,
    }
}