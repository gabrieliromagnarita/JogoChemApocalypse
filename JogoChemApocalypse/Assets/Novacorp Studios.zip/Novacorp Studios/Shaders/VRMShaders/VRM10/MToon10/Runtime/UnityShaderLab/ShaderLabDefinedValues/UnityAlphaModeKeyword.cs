﻿namespace VRMShaders.VRM10.MToon10.Runtime
{
    public static class UnityAlphaModeKeyword
    {
        public const string AlphaTest = "_ALPHATEST_ON";
        public const string AlphaBlend = "_ALPHABLEND_ON";
        public const string AlphaPremultiply = "_ALPHAPREMULTIPLY_ON";
    }
}