﻿namespace VRMShaders.VRM10.MToon10.Runtime
{
    public static class MToon10NormalMapKeyword
    {
        public const string On = "_NORMALMAP";
    }
}