﻿namespace VRMShaders.VRM10.MToon10.Runtime
{
    public static class MToon10EmissiveMapKeyword
    {
        public const string On = "_MTOON_EMISSIVEMAP";
    }
}