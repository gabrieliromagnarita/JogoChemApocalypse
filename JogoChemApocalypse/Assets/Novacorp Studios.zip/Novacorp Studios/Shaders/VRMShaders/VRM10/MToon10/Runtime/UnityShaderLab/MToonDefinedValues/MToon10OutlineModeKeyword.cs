﻿namespace VRMShaders.VRM10.MToon10.Runtime
{
    public static class MToon10OutlineModeKeyword
    {
        public const string World = "_MTOON_OUTLINE_WORLD";
        public const string Screen = "_MTOON_OUTLINE_SCREEN";
    }
}