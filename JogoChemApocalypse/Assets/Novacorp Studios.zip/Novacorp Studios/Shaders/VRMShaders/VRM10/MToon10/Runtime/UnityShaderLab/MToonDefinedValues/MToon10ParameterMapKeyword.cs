﻿namespace VRMShaders.VRM10.MToon10.Runtime
{
    public static class MToon10ParameterMapKeyword
    {
        public const string On = "_MTOON_PARAMETERMAP";
    }
}