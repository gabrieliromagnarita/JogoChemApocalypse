﻿namespace VRMShaders.VRM10.MToon10.Editor
{
    public enum MToon10EditorEditMode
    {
        Basic = 0,
        Advanced = 1,
    }
}