﻿namespace VRMShaders.VRM10.MToon10.Runtime
{
    public static class UnityRenderTag
    {
        public const string Key = "RenderType";
        public const string OpaqueValue = "Opaque";
        public const string TransparentCutoutValue = "TransparentCutout";
        public const string TransparentValue = "Transparent";
    }
}