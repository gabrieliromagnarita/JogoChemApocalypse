﻿namespace VRMShaders.VRM10.MToon10.Runtime
{
    public enum MToon10AlphaMode
    {
        Opaque = 0,
        Cutout = 1,
        Transparent = 2,
    }
}